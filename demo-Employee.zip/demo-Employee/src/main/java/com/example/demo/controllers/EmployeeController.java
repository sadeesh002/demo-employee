package com.example.demo.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entities.Employee;
import com.example.demo.services.EmployeeService;

@RestController
public class EmployeeController {
	@Autowired
	EmployeeService es;
	
	@PostMapping(value="/employees")
	public String addEmployee(@RequestBody Employee emp)
	{
		return es.insertEmployee(emp);
	}
	@GetMapping(value="/employees")
	public List<Employee> fetchAllEmployees()
	{
		return es.findAll();
	}
	@GetMapping("/employees/{id}")						//employees/105
	public Employee findEmployeeById(@PathVariable("id") int id)
	{
		return es.findByEmployeeId(id);
	}
	@GetMapping("/employees/byName/{empName}")
	public Employee findEmployeeByName(@PathVariable("empName") String eName)
	{
		return es.findByEmployeeName(eName);
	}
	@GetMapping("/employees/byEmployeeSalary/InRange/{sRange}/{eRange}")
	public List<Employee> findEmployeeBySalaryInRange(@PathVariable("sRange")int sR,@PathVariable("eRange")int eR) 
	{
		return es.findEmployeesInRange(sR,eR);
	}
	@PutMapping("/employees/{id}")					//employees/105
	public String modifyEmployee(@PathVariable("id") int id,@RequestBody Employee emp)
	{
		return es.updateEmployee(id,emp);
	}
	@DeleteMapping("/employees/{id}")
	public String deleteEmployeeById(@PathVariable("id") int id)
	{
		return es.deleteById(id);
	}
	@DeleteMapping("/employees/{ename}")
	public String deleteEmployeeById(@PathVariable("ename") String ename)
	{
		return es.deleteByName(ename);
	}
}